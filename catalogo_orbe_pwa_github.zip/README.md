# Orbe — Catálogo Interativo (PWA)

Este projeto é um catálogo de lista de preços que funciona como **PWA** (app instalável), pronto para publicar no **GitHub Pages**.

## Publicar no GitHub Pages (passo a passo)

1. Crie um repositório no GitHub (ex.: `catalogo-orbe`).
2. Envie todos os arquivos desta pasta para o repositório (*index.html*, *manifest.json*, *service-worker.js*, pasta *assets*, arquivo *.nojekyll*).
3. No GitHub, vá em **Settings → Pages**.
4. Em **Build and deployment**, escolha **Source: Deploy from a branch**.
5. Em **Branch**, selecione `main` (ou `master`) e a pasta **/** (root). Clique em **Save**.
6. Aguarde alguns instantes: o site ficará disponível em `https://SEU_USUARIO.github.io/NOME_DO_REPO/`.

## Como instalar no celular
- Abra o link do site no navegador (Chrome/Edge/Brave no Android; Safari no iOS).
- Use **Adicionar à tela inicial**.
- O app abrirá em tela cheia, com ícone.

## Importar imagens em lote
- Use o botão **“Importar imagens (CSV)”** e suba um arquivo com colunas `codigo;url` (ou `codigo,url`). Exemplo:
```
codigo;url
0521.1000;https://exemplo.com/monitor156.jpg
0433.1000;https://exemplo.com/camera_ahd.jpg
```
- O mapeamento é salvo no `localStorage` (do dispositivo). Para replicar em outros aparelhos, use **“Exportar imagens (CSV)”** e importe no outro dispositivo.

## PDF
- Clique em **Gerar PDF** e escolha “Salvar como PDF”.

## Observações
- Nenhum dado é enviado a servidores de terceiros; tudo roda localmente no navegador.
- Se alterar os dados do catálogo (no `index.html`), lembre de **dar um commit/push** e **atualizar o cache** no celular (forçar recarregamento).
